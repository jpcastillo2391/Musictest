from django.apps import AppConfig


class MusicsiteConfig(AppConfig):
    name = 'MusicSite'
